# Canteen-Management-System
 This is a simple demonstration of inner functionality of a Canteen-Management-System.This can be linked with any of the User Interface with some method calls!

# How it works?
- This can work according to the user interface to which it is linked.
- User can login and select the items which have to be oredered from the list of items available.
- The selected list can be viewed and also modified.
- Other features can be added with respect to the User Interface.

# Bug:
- This system has less security;can be breached.
- It does not contains any other payment methods.

